'use strict';
const path = require('path');
const fs = require('fs');
const { app, BrowserWindow, ipcMain, Tray, Menu, Notification, nativeImage, shell } = require('electron');

const isDev = process.argv.includes('--dev');
const ICON = path.join(__dirname, '..', 'assets', 'icon.png');
const DATA_FILE = () => path.join(app.getPath('userData'), 'findout-data.json');

const DEFAULT_DATA = {
  devices: [
    { id: 'd1', name: 'Chaves', icon: '🔑', battery: 87, lastSeen: 'Sala de estar' },
    { id: 'd2', name: 'Carteira', icon: '👛', battery: 64, lastSeen: 'Quarto' },
    { id: 'd3', name: 'Óculos', icon: '👓', battery: 92, lastSeen: 'Cozinha' }
  ],
  history: [],
  settings: { maxIntensity: 80, notifications: true, closeToTray: true, reduceMotion: false }
};

let win = null;
let tray = null;
let quitting = false;

/* ---------- Persistência simples em JSON (userData) ---------- */
function readData() {
  try {
    const raw = JSON.parse(fs.readFileSync(DATA_FILE(), 'utf8'));
    return { ...DEFAULT_DATA, ...raw, settings: { ...DEFAULT_DATA.settings, ...(raw.settings || {}) } };
  } catch {
    return structuredClone(DEFAULT_DATA);
  }
}
function writeData(data) {
  const tmp = DATA_FILE() + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2));
  fs.renameSync(tmp, DATA_FILE()); // escrita atômica
}

/* ---------- Janela ---------- */
function createWindow() {
  win = new BrowserWindow({
    width: 1180,
    height: 760,
    minWidth: 900,
    minHeight: 600,
    frame: false,
    backgroundColor: '#0b1020',
    show: false,
    icon: ICON,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      devTools: isDev
    }
  });

  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
  win.once('ready-to-show', () => win.show());

  // Links externos abrem no navegador; navegação interna é bloqueada
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https:\/\//.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', (e) => e.preventDefault());

  win.on('maximize', () => win.webContents.send('win:state', { maximized: true }));
  win.on('unmaximize', () => win.webContents.send('win:state', { maximized: false }));

  win.on('close', (e) => {
    if (!quitting && readData().settings.closeToTray) {
      e.preventDefault();
      win.hide();
    }
  });
  win.on('closed', () => { win = null; });
}

function showWindow() {
  if (!win) return createWindow();
  if (win.isMinimized()) win.restore();
  win.show();
  win.focus();
}

/* ---------- Bandeja do sistema ---------- */
function createTray() {
  const img = nativeImage.createFromPath(ICON).resize({ width: 18, height: 18 });
  tray = new Tray(img);
  tray.setToolTip('Find Out');
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: 'Abrir Find Out', click: showWindow },
    { label: 'Buscar objeto…', click: () => { showWindow(); win?.webContents.send('nav', 'track'); } },
    { type: 'separator' },
    { label: 'Sair', click: () => { quitting = true; app.quit(); } }
  ]));
  tray.on('click', showWindow);
}

/* ---------- IPC ---------- */
function registerIpc() {
  ipcMain.handle('data:get', () => readData());
  ipcMain.handle('data:set', (_e, data) => {
    if (!data || typeof data !== 'object' || !Array.isArray(data.devices)) return false;
    writeData({
      devices: data.devices.slice(0, 50),
      history: (data.history || []).slice(0, 200),
      settings: { ...DEFAULT_DATA.settings, ...(data.settings || {}) }
    });
    return true;
  });
  ipcMain.handle('app:info', () => ({
    version: app.getVersion(),
    electron: process.versions.electron,
    platform: process.platform
  }));
  ipcMain.on('notify', (_e, { title, body }) => {
    if (!Notification.isSupported() || !readData().settings.notifications) return;
    new Notification({ title: String(title).slice(0, 80), body: String(body).slice(0, 200), icon: ICON }).show();
  });
  ipcMain.on('win:minimize', () => win?.minimize());
  ipcMain.on('win:maximize', () => (win?.isMaximized() ? win.unmaximize() : win?.maximize()));
  ipcMain.on('win:close', () => win?.close());
}

/* ---------- Ciclo de vida ---------- */
if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', showWindow);
  app.whenReady().then(() => {
    registerIpc();
    createWindow();
    createTray();
    app.on('activate', showWindow);
  });
  app.on('before-quit', () => { quitting = true; });
  app.on('window-all-closed', () => {
    if (process.platform !== 'darwin' && quitting) app.quit();
  });
}
