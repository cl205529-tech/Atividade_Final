'use strict';
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('findout', {
  getData: () => ipcRenderer.invoke('data:get'),
  setData: (data) => ipcRenderer.invoke('data:set', data),
  info: () => ipcRenderer.invoke('app:info'),
  notify: (title, body) => ipcRenderer.send('notify', { title, body }),
  win: {
    minimize: () => ipcRenderer.send('win:minimize'),
    maximize: () => ipcRenderer.send('win:maximize'),
    close: () => ipcRenderer.send('win:close')
  },
  onNavigate: (cb) => ipcRenderer.on('nav', (_e, view) => cb(view))
});
