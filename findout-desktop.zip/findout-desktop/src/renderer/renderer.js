'use strict';

const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const MAX_DIST = 20;       // metros
const TOUCH_DIST = 0.3;    // distância para confirmar por toque

let state = { devices: [], history: [], settings: {} };
let search = null;          // { device, timer, auto }
let saveTimer = null;

/* ---------- Persistência ---------- */
function save() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => window.findout.setData(state), 200);
}

/* ---------- Utilidades ---------- */
function toast(msg) {
  const t = $('#toast');
  t.textContent = msg;
  t.hidden = false;
  clearTimeout(toast.t);
  toast.t = setTimeout(() => (t.hidden = true), 3000);
}
const fmtDate = (iso) => new Date(iso).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' });
const uid = () => 'd' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);

/* ---------- Navegação ---------- */
function go(view) {
  $$('.view').forEach((v) => v.classList.toggle('active', v.id === 'view-' + view));
  $$('.nav').forEach((n) => n.classList.toggle('active', n.dataset.nav === view));
  if (view === 'track') renderTrackSelect();
}
document.addEventListener('click', (e) => {
  const nav = e.target.closest('[data-nav]');
  if (nav) go(nav.dataset.nav);
});

/* ---------- Barra de título ---------- */
$('#wMin').onclick = () => window.findout.win.minimize();
$('#wMax').onclick = () => window.findout.win.maximize();
$('#wClose').onclick = () => window.findout.win.close();

/* ---------- Dispositivos ---------- */
function renderDevices() {
  const grid = $('#devGrid');
  grid.replaceChildren();
  if (!state.devices.length) {
    const p = document.createElement('p');
    p.className = 'empty';
    p.textContent = 'Nenhuma tag cadastrada. Clique em “Adicionar tag”.';
    grid.append(p);
    return;
  }
  for (const d of state.devices) {
    const card = document.createElement('article');
    card.className = 'card dev';
    const mk = (cls, txt) => { const el = document.createElement('div'); el.className = cls; el.textContent = txt; return el; };
    const acts = document.createElement('div');
    acts.className = 'acts';
    const find = document.createElement('button');
    find.className = 'btn btn-primary btn-sm';
    find.textContent = 'Buscar';
    find.onclick = () => { go('track'); $('#trackDevice').value = d.id; };
    const del = document.createElement('button');
    del.className = 'btn btn-danger btn-sm';
    del.textContent = 'Remover';
    del.onclick = () => {
      state.devices = state.devices.filter((x) => x.id !== d.id);
      save(); renderDevices(); toast(`“${d.name}” removido.`);
    };
    acts.append(find, del);
    card.append(
      mk('ico', d.icon), mk('nm', d.name),
      mk('meta', `Bateria ${d.battery}% · Visto: ${d.lastSeen}`),
      acts
    );
    grid.append(card);
  }
}

$('#btnAdd').onclick = () => { $('#addForm').hidden = false; $('#newName').focus(); };
$('#btnCancelAdd').onclick = () => { $('#addForm').hidden = true; $('#addForm').reset(); };
$('#addForm').onsubmit = (e) => {
  e.preventDefault();
  const name = $('#newName').value.trim();
  if (!name) return;
  state.devices.push({
    id: uid(), name, icon: $('#newIcon').value,
    battery: 100, lastSeen: 'Recém-adicionado'
  });
  save(); renderDevices();
  $('#addForm').reset(); $('#addForm').hidden = true;
  toast(`“${name}” adicionado.`);
};

/* ---------- Histórico ---------- */
function renderHistory() {
  const ul = $('#histList');
  ul.replaceChildren();
  if (!state.history.length) {
    const li = document.createElement('p');
    li.className = 'empty';
    li.textContent = 'Nenhuma busca concluída ainda.';
    ul.append(li);
    return;
  }
  for (const h of state.history) {
    const li = document.createElement('li');
    const a = document.createElement('span');
    a.textContent = `${h.icon} ${h.name} encontrado em ${h.seconds}s`;
    const b = document.createElement('span');
    b.className = 'when';
    b.textContent = fmtDate(h.date);
    li.append(a, b);
    ul.append(li);
  }
}
$('#btnClearHist').onclick = () => { state.history = []; save(); renderHistory(); };

/* ---------- Rastreamento ---------- */
function renderTrackSelect() {
  const sel = $('#trackDevice');
  const prev = sel.value;
  sel.replaceChildren();
  for (const d of state.devices) {
    const o = document.createElement('option');
    o.value = d.id;
    o.textContent = `${d.icon} ${d.name}`;
    sel.append(o);
  }
  if (prev) sel.value = prev;
  $('#btnStart').disabled = !state.devices.length || !!search;
}

/** Atualiza a interface de acordo com a distância (0–20 m). */
function applyDistance(d) {
  d = Math.max(0, Math.min(MAX_DIST, d));
  $('#distRange').value = d;
  $('#distLabel').textContent = d.toFixed(1);
  $('#distVal').textContent = d.toFixed(1);

  const cap = state.settings.maxIntensity / 100;
  const raw = 1 - d / MAX_DIST;                 // 0 (longe) → 1 (perto)
  const intensity = Math.round(raw * cap * 100);
  $('#intBar').style.width = intensity + '%';
  $('#intText').textContent = `Vibração ${intensity}%`;

  const wrist = $('#wrist'), radar = $('#trackRadar');
  const buzz = d < MAX_DIST - 0.5;
  wrist.classList.toggle('buzz', buzz);
  wrist.style.setProperty('--shake', (1 + raw * cap * 7).toFixed(1) + 'px');
  wrist.style.setProperty('--buzz', (0.6 - raw * 0.5).toFixed(2) + 's'); // mais perto = mais rápido
  radar.style.setProperty('--pulse', (2.4 - raw * 2).toFixed(2) + 's');

  const near = d <= TOUCH_DIST;
  $('#btnTouch').hidden = !near;
  $('#trackStatus').textContent =
    near ? 'Está aqui! Encoste a tag na pulseira para confirmar.' :
    d < 1.5 ? 'Muito perto — quase lá!' :
    d < 5 ? 'Esquentando… continue nessa direção.' :
    d < 12 ? 'Sinal fraco. Continue procurando.' : 'Longe. Comece a se movimentar.';
}

function startSearch() {
  const device = state.devices.find((x) => x.id === $('#trackDevice').value);
  if (!device) return;
  search = { device, startedAt: Date.now(), timer: null };
  $('#trackRadar').classList.add('live');
  $('#distRange').disabled = false;
  $('#btnAuto').disabled = false;
  $('#btnStop').disabled = false;
  $('#btnStart').disabled = true;
  $('#trackDevice').disabled = true;
  applyDistance(8 + Math.random() * 10);
  toast(`Buscando “${device.name}”…`);
}

function stopSearch() {
  if (!search) return;
  clearInterval(search.timer);
  search = null;
  $('#trackRadar').classList.remove('live');
  $('#wrist').classList.remove('buzz');
  $('#distRange').disabled = true;
  $('#btnAuto').disabled = true;
  $('#btnAuto').textContent = 'Caminhar';
  $('#btnStop').disabled = true;
  $('#btnStart').disabled = !state.devices.length;
  $('#trackDevice').disabled = false;
  $('#btnTouch').hidden = true;
  $('#distVal').textContent = '—';
  $('#intBar').style.width = '0';
  $('#intText').textContent = 'Vibração 0%';
  $('#trackStatus').textContent = 'Selecione um objeto e inicie a busca.';
}

function toggleAuto() {
  if (!search) return;
  if (search.timer) {
    clearInterval(search.timer);
    search.timer = null;
    $('#btnAuto').textContent = 'Caminhar';
    return;
  }
  $('#btnAuto').textContent = 'Pausar';
  search.timer = setInterval(() => {
    const cur = parseFloat($('#distRange').value);
    const next = cur - (0.15 + Math.random() * 0.15);
    applyDistance(next);
    if (next <= TOUCH_DIST) { clearInterval(search.timer); search.timer = null; $('#btnAuto').textContent = 'Caminhar'; }
  }, 200);
}

function confirmTouch() {
  if (!search) return;
  const { device, startedAt } = search;
  const seconds = Math.max(1, Math.round((Date.now() - startedAt) / 1000));
  state.history.unshift({ name: device.name, icon: device.icon, seconds, date: new Date().toISOString() });
  state.history = state.history.slice(0, 200);
  const dv = state.devices.find((x) => x.id === device.id);
  if (dv) dv.lastSeen = 'Agora mesmo';
  save(); renderHistory(); renderDevices();
  window.findout.notify('Objeto encontrado!', `“${device.name}” localizado em ${seconds}s.`);
  toast(`✔ “${device.name}” encontrado!`);
  stopSearch();
}

$('#btnStart').onclick = startSearch;
$('#btnStop').onclick = stopSearch;
$('#btnAuto').onclick = toggleAuto;
$('#btnTouch').onclick = confirmTouch;
$('#distRange').oninput = (e) => {
  if (search?.timer) { clearInterval(search.timer); search.timer = null; $('#btnAuto').textContent = 'Caminhar'; }
  applyDistance(parseFloat(e.target.value));
};

/* ---------- Configurações ---------- */
function applySettings() {
  const s = state.settings;
  $('#setIntensity').value = s.maxIntensity;
  $('#setIntLabel').textContent = s.maxIntensity;
  $('#setNotif').checked = s.notifications;
  $('#setTray').checked = s.closeToTray;
  $('#setMotion').checked = s.reduceMotion;
  document.body.classList.toggle('reduce-motion', s.reduceMotion);
}
$('#setIntensity').oninput = (e) => {
  state.settings.maxIntensity = +e.target.value;
  $('#setIntLabel').textContent = e.target.value;
  save();
};
$('#setNotif').onchange = (e) => { state.settings.notifications = e.target.checked; save(); };
$('#setTray').onchange = (e) => { state.settings.closeToTray = e.target.checked; save(); };
$('#setMotion').onchange = (e) => { state.settings.reduceMotion = e.target.checked; applySettings(); save(); };

/* ---------- Inicialização ---------- */
(async function init() {
  state = await window.findout.getData();
  const info = await window.findout.info();
  $('#appInfo').textContent = `v${info.version} · Electron ${info.electron}`;
  applySettings(); renderDevices(); renderHistory(); renderTrackSelect();
  window.findout.onNavigate(go);
})();
