# Find Out — App Desktop (Electron)

Rastreamento tátil inteligente. Mesma identidade visual do site, agora como app desktop.

## Rodar
```bash
npm install
npm start          # modo normal
npm run dev        # com DevTools
```

## Gerar instaladores
```bash
npm run dist:win     # Windows (.exe)
npm run dist:mac     # macOS (.dmg)
npm run dist:linux   # AppImage + .deb
```

## O que tem
- Janela sem moldura com barra de título própria (minimizar / maximizar / fechar)
- Início, Rastrear (simulador de vibração por distância), Dispositivos (CRUD), Histórico e Configurações
- Ícone na bandeja do sistema (fechar a janela mantém o app rodando, configurável)
- Notificação do sistema ao encontrar um objeto
- Instância única
- Dados salvos em JSON na pasta do usuário (`userData/findout-data.json`)
- Segurança: `contextIsolation`, `sandbox`, sem `nodeIntegration`, CSP restritiva, IPC validado

## Estrutura
```
src/main.js            processo principal (janela, tray, IPC, persistência)
src/preload.js         ponte segura (contextBridge)
src/renderer/          interface (HTML/CSS/JS)
assets/icon.png        ícone do app e da bandeja
```

## Próximos passos
Trocar o simulador por Bluetooth LE real (`navigator.bluetooth` / `@abandonware/noble`),
usando o RSSI da tag para calcular a distância.
